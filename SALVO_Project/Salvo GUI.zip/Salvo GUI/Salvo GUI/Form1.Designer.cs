﻿namespace Salvo_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.button193 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.button196 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.button199 = new System.Windows.Forms.Button();
            this.button200 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.self = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button201 = new System.Windows.Forms.Button();
            this.button202 = new System.Windows.Forms.Button();
            this.button203 = new System.Windows.Forms.Button();
            this.button204 = new System.Windows.Forms.Button();
            this.button205 = new System.Windows.Forms.Button();
            this.button206 = new System.Windows.Forms.Button();
            this.button208 = new System.Windows.Forms.Button();
            this.button209 = new System.Windows.Forms.Button();
            this.button207 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(13, 363);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 30);
            this.label12.TabIndex = 11;
            this.label12.Text = "9";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(13, 327);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 30);
            this.label13.TabIndex = 12;
            this.label13.Text = "8";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(13, 291);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 30);
            this.label14.TabIndex = 13;
            this.label14.Text = "7";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(13, 255);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 30);
            this.label15.TabIndex = 14;
            this.label15.Text = "6";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(13, 218);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(30, 30);
            this.label16.TabIndex = 15;
            this.label16.Text = "5";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(13, 183);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 30);
            this.label17.TabIndex = 16;
            this.label17.Text = "4";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(13, 147);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(30, 30);
            this.label18.TabIndex = 17;
            this.label18.Text = "3";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(373, 45);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(30, 30);
            this.label19.TabIndex = 18;
            this.label19.Text = "J";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(13, 111);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 30);
            this.label20.TabIndex = 19;
            this.label20.Text = "2";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(13, 75);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(30, 30);
            this.label21.TabIndex = 20;
            this.label21.Text = "1";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(301, 45);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(30, 30);
            this.label22.TabIndex = 21;
            this.label22.Text = "H";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(337, 45);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(30, 30);
            this.label23.TabIndex = 22;
            this.label23.Text = "I";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(265, 45);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(30, 30);
            this.label24.TabIndex = 23;
            this.label24.Text = "G";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(229, 45);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(30, 30);
            this.label25.TabIndex = 24;
            this.label25.Text = "F";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(193, 45);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(30, 30);
            this.label26.TabIndex = 25;
            this.label26.Text = "E";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(157, 45);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(30, 30);
            this.label27.TabIndex = 26;
            this.label27.Text = "D";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(121, 45);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(30, 30);
            this.label28.TabIndex = 27;
            this.label28.Text = "C";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(85, 45);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 30);
            this.label29.TabIndex = 28;
            this.label29.Text = "B";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(49, 45);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(30, 30);
            this.label30.TabIndex = 29;
            this.label30.Text = "A";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.CadetBlue;
            this.button1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button1.Location = new System.Drawing.Point(49, 75);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(30, 30);
            this.button1.TabIndex = 47;
            this.button1.Text = " ";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.CadetBlue;
            this.button28.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button28.Location = new System.Drawing.Point(373, 75);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(30, 30);
            this.button28.TabIndex = 74;
            this.button28.Text = " ";
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.CadetBlue;
            this.button34.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button34.Location = new System.Drawing.Point(337, 75);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(30, 30);
            this.button34.TabIndex = 80;
            this.button34.Text = " ";
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.CadetBlue;
            this.button35.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button35.Location = new System.Drawing.Point(301, 75);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(30, 30);
            this.button35.TabIndex = 81;
            this.button35.Text = " ";
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.CadetBlue;
            this.button36.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button36.Location = new System.Drawing.Point(193, 75);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(30, 30);
            this.button36.TabIndex = 82;
            this.button36.Text = " ";
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.CadetBlue;
            this.button37.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button37.Location = new System.Drawing.Point(265, 75);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(30, 30);
            this.button37.TabIndex = 83;
            this.button37.Text = " ";
            this.button37.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.CadetBlue;
            this.button38.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button38.Location = new System.Drawing.Point(229, 75);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(30, 30);
            this.button38.TabIndex = 84;
            this.button38.Text = " ";
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.CadetBlue;
            this.button39.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button39.Location = new System.Drawing.Point(157, 75);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(30, 30);
            this.button39.TabIndex = 85;
            this.button39.Text = " ";
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.CadetBlue;
            this.button40.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button40.Location = new System.Drawing.Point(121, 75);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(30, 30);
            this.button40.TabIndex = 86;
            this.button40.Text = " ";
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.CadetBlue;
            this.button41.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button41.Location = new System.Drawing.Point(85, 75);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(30, 30);
            this.button41.TabIndex = 87;
            this.button41.Text = " ";
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.CadetBlue;
            this.button2.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button2.Location = new System.Drawing.Point(85, 111);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 30);
            this.button2.TabIndex = 97;
            this.button2.Text = " ";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.CadetBlue;
            this.button3.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button3.Location = new System.Drawing.Point(121, 111);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(30, 30);
            this.button3.TabIndex = 96;
            this.button3.Text = " ";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.CadetBlue;
            this.button4.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button4.Location = new System.Drawing.Point(157, 111);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(30, 30);
            this.button4.TabIndex = 95;
            this.button4.Text = " ";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.CadetBlue;
            this.button5.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button5.Location = new System.Drawing.Point(229, 111);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(30, 30);
            this.button5.TabIndex = 94;
            this.button5.Text = " ";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.CadetBlue;
            this.button6.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button6.Location = new System.Drawing.Point(265, 111);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(30, 30);
            this.button6.TabIndex = 93;
            this.button6.Text = " ";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.CadetBlue;
            this.button7.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button7.Location = new System.Drawing.Point(193, 111);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(30, 30);
            this.button7.TabIndex = 92;
            this.button7.Text = " ";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.CadetBlue;
            this.button8.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button8.Location = new System.Drawing.Point(301, 111);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(30, 30);
            this.button8.TabIndex = 91;
            this.button8.Text = " ";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.CadetBlue;
            this.button9.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button9.Location = new System.Drawing.Point(337, 111);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(30, 30);
            this.button9.TabIndex = 90;
            this.button9.Text = " ";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.CadetBlue;
            this.button10.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button10.Location = new System.Drawing.Point(373, 111);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(30, 30);
            this.button10.TabIndex = 89;
            this.button10.Text = " ";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.CadetBlue;
            this.button11.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button11.Location = new System.Drawing.Point(49, 111);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(30, 30);
            this.button11.TabIndex = 88;
            this.button11.Text = " ";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.CadetBlue;
            this.button12.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button12.Location = new System.Drawing.Point(85, 147);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(30, 30);
            this.button12.TabIndex = 107;
            this.button12.Text = " ";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.CadetBlue;
            this.button13.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button13.Location = new System.Drawing.Point(121, 147);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(30, 30);
            this.button13.TabIndex = 106;
            this.button13.Text = " ";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.CadetBlue;
            this.button14.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button14.Location = new System.Drawing.Point(157, 147);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(30, 30);
            this.button14.TabIndex = 105;
            this.button14.Text = " ";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.CadetBlue;
            this.button15.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button15.Location = new System.Drawing.Point(229, 147);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(30, 30);
            this.button15.TabIndex = 104;
            this.button15.Text = " ";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.CadetBlue;
            this.button16.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button16.Location = new System.Drawing.Point(265, 147);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(30, 30);
            this.button16.TabIndex = 103;
            this.button16.Text = " ";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.CadetBlue;
            this.button17.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button17.Location = new System.Drawing.Point(193, 147);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(30, 30);
            this.button17.TabIndex = 102;
            this.button17.Text = " ";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.CadetBlue;
            this.button18.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button18.Location = new System.Drawing.Point(301, 147);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(30, 30);
            this.button18.TabIndex = 101;
            this.button18.Text = " ";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.CadetBlue;
            this.button19.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button19.Location = new System.Drawing.Point(337, 147);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(30, 30);
            this.button19.TabIndex = 100;
            this.button19.Text = " ";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.CadetBlue;
            this.button20.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button20.Location = new System.Drawing.Point(373, 147);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(30, 30);
            this.button20.TabIndex = 99;
            this.button20.Text = " ";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.CadetBlue;
            this.button21.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button21.Location = new System.Drawing.Point(49, 147);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(30, 30);
            this.button21.TabIndex = 98;
            this.button21.Text = " ";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.CadetBlue;
            this.button22.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button22.Location = new System.Drawing.Point(85, 183);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(30, 30);
            this.button22.TabIndex = 117;
            this.button22.Text = " ";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.CadetBlue;
            this.button23.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button23.Location = new System.Drawing.Point(121, 183);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(30, 30);
            this.button23.TabIndex = 116;
            this.button23.Text = " ";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.CadetBlue;
            this.button24.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button24.Location = new System.Drawing.Point(157, 183);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(30, 30);
            this.button24.TabIndex = 115;
            this.button24.Text = " ";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.CadetBlue;
            this.button25.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button25.Location = new System.Drawing.Point(229, 183);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(30, 30);
            this.button25.TabIndex = 114;
            this.button25.Text = " ";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.CadetBlue;
            this.button26.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button26.Location = new System.Drawing.Point(265, 183);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(30, 30);
            this.button26.TabIndex = 113;
            this.button26.Text = " ";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.CadetBlue;
            this.button27.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button27.Location = new System.Drawing.Point(193, 183);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(30, 30);
            this.button27.TabIndex = 112;
            this.button27.Text = " ";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.CadetBlue;
            this.button29.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button29.Location = new System.Drawing.Point(301, 183);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(30, 30);
            this.button29.TabIndex = 111;
            this.button29.Text = " ";
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.CadetBlue;
            this.button30.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button30.Location = new System.Drawing.Point(337, 183);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(30, 30);
            this.button30.TabIndex = 110;
            this.button30.Text = " ";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.CadetBlue;
            this.button31.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button31.Location = new System.Drawing.Point(373, 183);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(30, 30);
            this.button31.TabIndex = 109;
            this.button31.Text = " ";
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.CadetBlue;
            this.button32.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button32.Location = new System.Drawing.Point(49, 183);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(30, 30);
            this.button32.TabIndex = 108;
            this.button32.Text = " ";
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.CadetBlue;
            this.button33.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button33.Location = new System.Drawing.Point(85, 219);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(30, 30);
            this.button33.TabIndex = 127;
            this.button33.Text = " ";
            this.button33.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.CadetBlue;
            this.button42.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button42.Location = new System.Drawing.Point(121, 219);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(30, 30);
            this.button42.TabIndex = 126;
            this.button42.Text = " ";
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.CadetBlue;
            this.button43.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button43.Location = new System.Drawing.Point(157, 219);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(30, 30);
            this.button43.TabIndex = 125;
            this.button43.Text = " ";
            this.button43.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.CadetBlue;
            this.button44.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button44.Location = new System.Drawing.Point(229, 219);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(30, 30);
            this.button44.TabIndex = 124;
            this.button44.Text = " ";
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.CadetBlue;
            this.button45.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button45.Location = new System.Drawing.Point(265, 219);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(30, 30);
            this.button45.TabIndex = 123;
            this.button45.Text = " ";
            this.button45.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.CadetBlue;
            this.button46.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button46.Location = new System.Drawing.Point(193, 219);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(30, 30);
            this.button46.TabIndex = 122;
            this.button46.Text = " ";
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.CadetBlue;
            this.button47.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button47.Location = new System.Drawing.Point(301, 219);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(30, 30);
            this.button47.TabIndex = 121;
            this.button47.Text = " ";
            this.button47.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.CadetBlue;
            this.button48.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button48.Location = new System.Drawing.Point(337, 219);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(30, 30);
            this.button48.TabIndex = 120;
            this.button48.Text = " ";
            this.button48.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.CadetBlue;
            this.button49.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button49.Location = new System.Drawing.Point(373, 219);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(30, 30);
            this.button49.TabIndex = 119;
            this.button49.Text = " ";
            this.button49.UseVisualStyleBackColor = false;
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.CadetBlue;
            this.button50.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button50.Location = new System.Drawing.Point(49, 219);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(30, 30);
            this.button50.TabIndex = 118;
            this.button50.Text = " ";
            this.button50.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.CadetBlue;
            this.button51.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button51.Location = new System.Drawing.Point(85, 255);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(30, 30);
            this.button51.TabIndex = 137;
            this.button51.Text = " ";
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.CadetBlue;
            this.button52.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button52.Location = new System.Drawing.Point(121, 255);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(30, 30);
            this.button52.TabIndex = 136;
            this.button52.Text = " ";
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.CadetBlue;
            this.button53.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button53.Location = new System.Drawing.Point(157, 255);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(30, 30);
            this.button53.TabIndex = 135;
            this.button53.Text = " ";
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.CadetBlue;
            this.button54.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button54.Location = new System.Drawing.Point(229, 255);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(30, 30);
            this.button54.TabIndex = 134;
            this.button54.Text = " ";
            this.button54.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.CadetBlue;
            this.button55.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button55.Location = new System.Drawing.Point(265, 255);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(30, 30);
            this.button55.TabIndex = 133;
            this.button55.Text = " ";
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.CadetBlue;
            this.button56.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button56.Location = new System.Drawing.Point(193, 255);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(30, 30);
            this.button56.TabIndex = 132;
            this.button56.Text = " ";
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.CadetBlue;
            this.button57.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button57.Location = new System.Drawing.Point(301, 255);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(30, 30);
            this.button57.TabIndex = 131;
            this.button57.Text = " ";
            this.button57.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.CadetBlue;
            this.button58.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button58.Location = new System.Drawing.Point(337, 255);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(30, 30);
            this.button58.TabIndex = 130;
            this.button58.Text = " ";
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.CadetBlue;
            this.button59.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button59.Location = new System.Drawing.Point(373, 255);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(30, 30);
            this.button59.TabIndex = 129;
            this.button59.Text = " ";
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.CadetBlue;
            this.button60.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button60.Location = new System.Drawing.Point(49, 255);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(30, 30);
            this.button60.TabIndex = 128;
            this.button60.Text = " ";
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.CadetBlue;
            this.button61.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button61.Location = new System.Drawing.Point(85, 291);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(30, 30);
            this.button61.TabIndex = 147;
            this.button61.Text = " ";
            this.button61.UseVisualStyleBackColor = false;
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.CadetBlue;
            this.button62.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button62.Location = new System.Drawing.Point(121, 291);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(30, 30);
            this.button62.TabIndex = 146;
            this.button62.Text = " ";
            this.button62.UseVisualStyleBackColor = false;
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.CadetBlue;
            this.button63.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button63.Location = new System.Drawing.Point(157, 291);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(30, 30);
            this.button63.TabIndex = 145;
            this.button63.Text = " ";
            this.button63.UseVisualStyleBackColor = false;
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.CadetBlue;
            this.button64.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button64.Location = new System.Drawing.Point(229, 291);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(30, 30);
            this.button64.TabIndex = 144;
            this.button64.Text = " ";
            this.button64.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.CadetBlue;
            this.button65.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button65.Location = new System.Drawing.Point(265, 291);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(30, 30);
            this.button65.TabIndex = 143;
            this.button65.Text = " ";
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.CadetBlue;
            this.button66.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button66.Location = new System.Drawing.Point(193, 291);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(30, 30);
            this.button66.TabIndex = 142;
            this.button66.Text = " ";
            this.button66.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.CadetBlue;
            this.button67.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button67.Location = new System.Drawing.Point(301, 291);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(30, 30);
            this.button67.TabIndex = 141;
            this.button67.Text = " ";
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.CadetBlue;
            this.button68.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button68.Location = new System.Drawing.Point(337, 291);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(30, 30);
            this.button68.TabIndex = 140;
            this.button68.Text = " ";
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.Color.CadetBlue;
            this.button69.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button69.Location = new System.Drawing.Point(373, 291);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(30, 30);
            this.button69.TabIndex = 139;
            this.button69.Text = " ";
            this.button69.UseVisualStyleBackColor = false;
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.CadetBlue;
            this.button70.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button70.Location = new System.Drawing.Point(49, 291);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(30, 30);
            this.button70.TabIndex = 138;
            this.button70.Text = " ";
            this.button70.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.CadetBlue;
            this.button71.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button71.Location = new System.Drawing.Point(85, 327);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(30, 30);
            this.button71.TabIndex = 157;
            this.button71.Text = " ";
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.CadetBlue;
            this.button72.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button72.Location = new System.Drawing.Point(121, 327);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(30, 30);
            this.button72.TabIndex = 156;
            this.button72.Text = " ";
            this.button72.UseVisualStyleBackColor = false;
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.CadetBlue;
            this.button73.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button73.Location = new System.Drawing.Point(157, 327);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(30, 30);
            this.button73.TabIndex = 155;
            this.button73.Text = " ";
            this.button73.UseVisualStyleBackColor = false;
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.Color.CadetBlue;
            this.button74.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button74.Location = new System.Drawing.Point(229, 327);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(30, 30);
            this.button74.TabIndex = 154;
            this.button74.Text = " ";
            this.button74.UseVisualStyleBackColor = false;
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.Color.CadetBlue;
            this.button75.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button75.Location = new System.Drawing.Point(265, 327);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(30, 30);
            this.button75.TabIndex = 153;
            this.button75.Text = " ";
            this.button75.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.CadetBlue;
            this.button76.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button76.Location = new System.Drawing.Point(193, 327);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(30, 30);
            this.button76.TabIndex = 152;
            this.button76.Text = " ";
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.CadetBlue;
            this.button77.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button77.Location = new System.Drawing.Point(301, 327);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(30, 30);
            this.button77.TabIndex = 151;
            this.button77.Text = " ";
            this.button77.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.Color.CadetBlue;
            this.button78.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button78.Location = new System.Drawing.Point(337, 327);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(30, 30);
            this.button78.TabIndex = 150;
            this.button78.Text = " ";
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.CadetBlue;
            this.button79.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button79.Location = new System.Drawing.Point(373, 327);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(30, 30);
            this.button79.TabIndex = 149;
            this.button79.Text = " ";
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.CadetBlue;
            this.button80.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button80.Location = new System.Drawing.Point(49, 327);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(30, 30);
            this.button80.TabIndex = 148;
            this.button80.Text = " ";
            this.button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.Color.CadetBlue;
            this.button81.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button81.Location = new System.Drawing.Point(85, 363);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(30, 30);
            this.button81.TabIndex = 167;
            this.button81.Text = " ";
            this.button81.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.Color.CadetBlue;
            this.button82.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button82.Location = new System.Drawing.Point(121, 363);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(30, 30);
            this.button82.TabIndex = 166;
            this.button82.Text = " ";
            this.button82.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.Color.CadetBlue;
            this.button83.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button83.Location = new System.Drawing.Point(157, 363);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(30, 30);
            this.button83.TabIndex = 165;
            this.button83.Text = " ";
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.Color.CadetBlue;
            this.button84.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button84.Location = new System.Drawing.Point(229, 363);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(30, 30);
            this.button84.TabIndex = 164;
            this.button84.Text = " ";
            this.button84.UseVisualStyleBackColor = false;
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.Color.CadetBlue;
            this.button85.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button85.Location = new System.Drawing.Point(265, 363);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(30, 30);
            this.button85.TabIndex = 163;
            this.button85.Text = " ";
            this.button85.UseVisualStyleBackColor = false;
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.Color.CadetBlue;
            this.button86.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button86.Location = new System.Drawing.Point(193, 363);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(30, 30);
            this.button86.TabIndex = 162;
            this.button86.Text = " ";
            this.button86.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.Color.CadetBlue;
            this.button87.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button87.Location = new System.Drawing.Point(301, 363);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(30, 30);
            this.button87.TabIndex = 161;
            this.button87.Text = " ";
            this.button87.UseVisualStyleBackColor = false;
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.CadetBlue;
            this.button88.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button88.Location = new System.Drawing.Point(337, 363);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(30, 30);
            this.button88.TabIndex = 160;
            this.button88.Text = " ";
            this.button88.UseVisualStyleBackColor = false;
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.Color.CadetBlue;
            this.button89.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button89.Location = new System.Drawing.Point(373, 363);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(30, 30);
            this.button89.TabIndex = 159;
            this.button89.Text = " ";
            this.button89.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.Color.CadetBlue;
            this.button90.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button90.Location = new System.Drawing.Point(49, 363);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(30, 30);
            this.button90.TabIndex = 158;
            this.button90.Text = " ";
            this.button90.UseVisualStyleBackColor = false;
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.Color.CadetBlue;
            this.button91.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button91.Location = new System.Drawing.Point(85, 399);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(30, 30);
            this.button91.TabIndex = 177;
            this.button91.Text = " ";
            this.button91.UseVisualStyleBackColor = false;
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.Color.CadetBlue;
            this.button92.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button92.Location = new System.Drawing.Point(121, 399);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(30, 30);
            this.button92.TabIndex = 176;
            this.button92.Text = " ";
            this.button92.UseVisualStyleBackColor = false;
            // 
            // button93
            // 
            this.button93.BackColor = System.Drawing.Color.CadetBlue;
            this.button93.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button93.Location = new System.Drawing.Point(157, 399);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(30, 30);
            this.button93.TabIndex = 175;
            this.button93.Text = " ";
            this.button93.UseVisualStyleBackColor = false;
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.Color.CadetBlue;
            this.button94.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button94.Location = new System.Drawing.Point(229, 399);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(30, 30);
            this.button94.TabIndex = 174;
            this.button94.Text = " ";
            this.button94.UseVisualStyleBackColor = false;
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.Color.CadetBlue;
            this.button95.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button95.Location = new System.Drawing.Point(265, 399);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(30, 30);
            this.button95.TabIndex = 173;
            this.button95.Text = " ";
            this.button95.UseVisualStyleBackColor = false;
            // 
            // button96
            // 
            this.button96.BackColor = System.Drawing.Color.CadetBlue;
            this.button96.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button96.Location = new System.Drawing.Point(193, 399);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(30, 30);
            this.button96.TabIndex = 172;
            this.button96.Text = " ";
            this.button96.UseVisualStyleBackColor = false;
            // 
            // button97
            // 
            this.button97.BackColor = System.Drawing.Color.CadetBlue;
            this.button97.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button97.Location = new System.Drawing.Point(301, 399);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(30, 30);
            this.button97.TabIndex = 171;
            this.button97.Text = " ";
            this.button97.UseVisualStyleBackColor = false;
            // 
            // button98
            // 
            this.button98.BackColor = System.Drawing.Color.CadetBlue;
            this.button98.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button98.Location = new System.Drawing.Point(337, 399);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(30, 30);
            this.button98.TabIndex = 170;
            this.button98.Text = " ";
            this.button98.UseVisualStyleBackColor = false;
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.Color.CadetBlue;
            this.button99.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button99.Location = new System.Drawing.Point(373, 399);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(30, 30);
            this.button99.TabIndex = 169;
            this.button99.Text = " ";
            this.button99.UseVisualStyleBackColor = false;
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.Color.CadetBlue;
            this.button100.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button100.Location = new System.Drawing.Point(49, 399);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(30, 30);
            this.button100.TabIndex = 168;
            this.button100.Text = " ";
            this.button100.UseVisualStyleBackColor = false;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(13, 399);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(30, 30);
            this.label31.TabIndex = 178;
            this.label31.Text = "10";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button101
            // 
            this.button101.BackColor = System.Drawing.Color.CadetBlue;
            this.button101.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button101.Location = new System.Drawing.Point(909, 399);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(30, 30);
            this.button101.TabIndex = 298;
            this.button101.Text = " ";
            this.button101.UseVisualStyleBackColor = false;
            // 
            // button102
            // 
            this.button102.BackColor = System.Drawing.Color.CadetBlue;
            this.button102.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button102.Location = new System.Drawing.Point(945, 399);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(30, 30);
            this.button102.TabIndex = 297;
            this.button102.Text = " ";
            this.button102.UseVisualStyleBackColor = false;
            // 
            // button103
            // 
            this.button103.BackColor = System.Drawing.Color.CadetBlue;
            this.button103.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button103.Location = new System.Drawing.Point(981, 399);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(30, 30);
            this.button103.TabIndex = 296;
            this.button103.Text = " ";
            this.button103.UseVisualStyleBackColor = false;
            // 
            // button104
            // 
            this.button104.BackColor = System.Drawing.Color.CadetBlue;
            this.button104.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button104.Location = new System.Drawing.Point(1053, 399);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(30, 30);
            this.button104.TabIndex = 295;
            this.button104.Text = " ";
            this.button104.UseVisualStyleBackColor = false;
            // 
            // button105
            // 
            this.button105.BackColor = System.Drawing.Color.CadetBlue;
            this.button105.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button105.Location = new System.Drawing.Point(1089, 399);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(30, 30);
            this.button105.TabIndex = 294;
            this.button105.Text = " ";
            this.button105.UseVisualStyleBackColor = false;
            // 
            // button106
            // 
            this.button106.BackColor = System.Drawing.Color.CadetBlue;
            this.button106.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button106.Location = new System.Drawing.Point(1017, 399);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(30, 30);
            this.button106.TabIndex = 293;
            this.button106.Text = " ";
            this.button106.UseVisualStyleBackColor = false;
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.Color.CadetBlue;
            this.button107.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button107.Location = new System.Drawing.Point(1125, 399);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(30, 30);
            this.button107.TabIndex = 292;
            this.button107.Text = " ";
            this.button107.UseVisualStyleBackColor = false;
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.Color.CadetBlue;
            this.button108.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button108.Location = new System.Drawing.Point(1161, 399);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(30, 30);
            this.button108.TabIndex = 291;
            this.button108.Text = " ";
            this.button108.UseVisualStyleBackColor = false;
            // 
            // button109
            // 
            this.button109.BackColor = System.Drawing.Color.CadetBlue;
            this.button109.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button109.Location = new System.Drawing.Point(1197, 399);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(30, 30);
            this.button109.TabIndex = 290;
            this.button109.Text = " ";
            this.button109.UseVisualStyleBackColor = false;
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.Color.CadetBlue;
            this.button110.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button110.Location = new System.Drawing.Point(873, 399);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(30, 30);
            this.button110.TabIndex = 289;
            this.button110.Text = " ";
            this.button110.UseVisualStyleBackColor = false;
            // 
            // button111
            // 
            this.button111.BackColor = System.Drawing.Color.CadetBlue;
            this.button111.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button111.Location = new System.Drawing.Point(909, 363);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(30, 30);
            this.button111.TabIndex = 288;
            this.button111.Text = " ";
            this.button111.UseVisualStyleBackColor = false;
            // 
            // button112
            // 
            this.button112.BackColor = System.Drawing.Color.CadetBlue;
            this.button112.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button112.Location = new System.Drawing.Point(945, 363);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(30, 30);
            this.button112.TabIndex = 287;
            this.button112.Text = " ";
            this.button112.UseVisualStyleBackColor = false;
            // 
            // button113
            // 
            this.button113.BackColor = System.Drawing.Color.CadetBlue;
            this.button113.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button113.Location = new System.Drawing.Point(981, 363);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(30, 30);
            this.button113.TabIndex = 286;
            this.button113.Text = " ";
            this.button113.UseVisualStyleBackColor = false;
            // 
            // button114
            // 
            this.button114.BackColor = System.Drawing.Color.CadetBlue;
            this.button114.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button114.Location = new System.Drawing.Point(1053, 363);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(30, 30);
            this.button114.TabIndex = 285;
            this.button114.Text = " ";
            this.button114.UseVisualStyleBackColor = false;
            // 
            // button115
            // 
            this.button115.BackColor = System.Drawing.Color.CadetBlue;
            this.button115.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button115.Location = new System.Drawing.Point(1089, 363);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(30, 30);
            this.button115.TabIndex = 284;
            this.button115.Text = " ";
            this.button115.UseVisualStyleBackColor = false;
            // 
            // button116
            // 
            this.button116.BackColor = System.Drawing.Color.CadetBlue;
            this.button116.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button116.Location = new System.Drawing.Point(1017, 363);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(30, 30);
            this.button116.TabIndex = 283;
            this.button116.Text = " ";
            this.button116.UseVisualStyleBackColor = false;
            // 
            // button117
            // 
            this.button117.BackColor = System.Drawing.Color.CadetBlue;
            this.button117.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button117.Location = new System.Drawing.Point(1125, 363);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(30, 30);
            this.button117.TabIndex = 282;
            this.button117.Text = " ";
            this.button117.UseVisualStyleBackColor = false;
            // 
            // button118
            // 
            this.button118.BackColor = System.Drawing.Color.CadetBlue;
            this.button118.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button118.Location = new System.Drawing.Point(1161, 363);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(30, 30);
            this.button118.TabIndex = 281;
            this.button118.Text = " ";
            this.button118.UseVisualStyleBackColor = false;
            // 
            // button119
            // 
            this.button119.BackColor = System.Drawing.Color.CadetBlue;
            this.button119.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button119.Location = new System.Drawing.Point(1197, 363);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(30, 30);
            this.button119.TabIndex = 280;
            this.button119.Text = " ";
            this.button119.UseVisualStyleBackColor = false;
            // 
            // button120
            // 
            this.button120.BackColor = System.Drawing.Color.CadetBlue;
            this.button120.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button120.Location = new System.Drawing.Point(873, 363);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(30, 30);
            this.button120.TabIndex = 279;
            this.button120.Text = " ";
            this.button120.UseVisualStyleBackColor = false;
            // 
            // button121
            // 
            this.button121.BackColor = System.Drawing.Color.CadetBlue;
            this.button121.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button121.Location = new System.Drawing.Point(909, 327);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(30, 30);
            this.button121.TabIndex = 278;
            this.button121.Text = " ";
            this.button121.UseVisualStyleBackColor = false;
            // 
            // button122
            // 
            this.button122.BackColor = System.Drawing.Color.CadetBlue;
            this.button122.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button122.Location = new System.Drawing.Point(945, 327);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(30, 30);
            this.button122.TabIndex = 277;
            this.button122.Text = " ";
            this.button122.UseVisualStyleBackColor = false;
            // 
            // button123
            // 
            this.button123.BackColor = System.Drawing.Color.CadetBlue;
            this.button123.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button123.Location = new System.Drawing.Point(981, 327);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(30, 30);
            this.button123.TabIndex = 276;
            this.button123.Text = " ";
            this.button123.UseVisualStyleBackColor = false;
            // 
            // button124
            // 
            this.button124.BackColor = System.Drawing.Color.CadetBlue;
            this.button124.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button124.Location = new System.Drawing.Point(1053, 327);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(30, 30);
            this.button124.TabIndex = 275;
            this.button124.Text = " ";
            this.button124.UseVisualStyleBackColor = false;
            // 
            // button125
            // 
            this.button125.BackColor = System.Drawing.Color.CadetBlue;
            this.button125.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button125.Location = new System.Drawing.Point(1089, 327);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(30, 30);
            this.button125.TabIndex = 274;
            this.button125.Text = " ";
            this.button125.UseVisualStyleBackColor = false;
            // 
            // button126
            // 
            this.button126.BackColor = System.Drawing.Color.CadetBlue;
            this.button126.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button126.Location = new System.Drawing.Point(1017, 327);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(30, 30);
            this.button126.TabIndex = 273;
            this.button126.Text = " ";
            this.button126.UseVisualStyleBackColor = false;
            // 
            // button127
            // 
            this.button127.BackColor = System.Drawing.Color.CadetBlue;
            this.button127.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button127.Location = new System.Drawing.Point(1125, 327);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(30, 30);
            this.button127.TabIndex = 272;
            this.button127.Text = " ";
            this.button127.UseVisualStyleBackColor = false;
            // 
            // button128
            // 
            this.button128.BackColor = System.Drawing.Color.CadetBlue;
            this.button128.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button128.Location = new System.Drawing.Point(1161, 327);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(30, 30);
            this.button128.TabIndex = 271;
            this.button128.Text = " ";
            this.button128.UseVisualStyleBackColor = false;
            // 
            // button129
            // 
            this.button129.BackColor = System.Drawing.Color.CadetBlue;
            this.button129.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button129.Location = new System.Drawing.Point(1197, 327);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(30, 30);
            this.button129.TabIndex = 270;
            this.button129.Text = " ";
            this.button129.UseVisualStyleBackColor = false;
            // 
            // button130
            // 
            this.button130.BackColor = System.Drawing.Color.CadetBlue;
            this.button130.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button130.Location = new System.Drawing.Point(873, 327);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(30, 30);
            this.button130.TabIndex = 269;
            this.button130.Text = " ";
            this.button130.UseVisualStyleBackColor = false;
            // 
            // button131
            // 
            this.button131.BackColor = System.Drawing.Color.CadetBlue;
            this.button131.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button131.Location = new System.Drawing.Point(909, 291);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(30, 30);
            this.button131.TabIndex = 268;
            this.button131.Text = " ";
            this.button131.UseVisualStyleBackColor = false;
            // 
            // button132
            // 
            this.button132.BackColor = System.Drawing.Color.CadetBlue;
            this.button132.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button132.Location = new System.Drawing.Point(945, 291);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(30, 30);
            this.button132.TabIndex = 267;
            this.button132.Text = " ";
            this.button132.UseVisualStyleBackColor = false;
            // 
            // button133
            // 
            this.button133.BackColor = System.Drawing.Color.CadetBlue;
            this.button133.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button133.Location = new System.Drawing.Point(981, 291);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(30, 30);
            this.button133.TabIndex = 266;
            this.button133.Text = " ";
            this.button133.UseVisualStyleBackColor = false;
            // 
            // button134
            // 
            this.button134.BackColor = System.Drawing.Color.CadetBlue;
            this.button134.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button134.Location = new System.Drawing.Point(1053, 291);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(30, 30);
            this.button134.TabIndex = 265;
            this.button134.Text = " ";
            this.button134.UseVisualStyleBackColor = false;
            // 
            // button135
            // 
            this.button135.BackColor = System.Drawing.Color.CadetBlue;
            this.button135.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button135.Location = new System.Drawing.Point(1089, 291);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(30, 30);
            this.button135.TabIndex = 264;
            this.button135.Text = " ";
            this.button135.UseVisualStyleBackColor = false;
            // 
            // button136
            // 
            this.button136.BackColor = System.Drawing.Color.CadetBlue;
            this.button136.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button136.Location = new System.Drawing.Point(1017, 291);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(30, 30);
            this.button136.TabIndex = 263;
            this.button136.Text = " ";
            this.button136.UseVisualStyleBackColor = false;
            // 
            // button137
            // 
            this.button137.BackColor = System.Drawing.Color.CadetBlue;
            this.button137.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button137.Location = new System.Drawing.Point(1125, 291);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(30, 30);
            this.button137.TabIndex = 262;
            this.button137.Text = " ";
            this.button137.UseVisualStyleBackColor = false;
            // 
            // button138
            // 
            this.button138.BackColor = System.Drawing.Color.CadetBlue;
            this.button138.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button138.Location = new System.Drawing.Point(1161, 291);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(30, 30);
            this.button138.TabIndex = 261;
            this.button138.Text = " ";
            this.button138.UseVisualStyleBackColor = false;
            // 
            // button139
            // 
            this.button139.BackColor = System.Drawing.Color.CadetBlue;
            this.button139.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button139.Location = new System.Drawing.Point(1197, 291);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(30, 30);
            this.button139.TabIndex = 260;
            this.button139.Text = " ";
            this.button139.UseVisualStyleBackColor = false;
            // 
            // button140
            // 
            this.button140.BackColor = System.Drawing.Color.CadetBlue;
            this.button140.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button140.Location = new System.Drawing.Point(873, 291);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(30, 30);
            this.button140.TabIndex = 259;
            this.button140.Text = " ";
            this.button140.UseVisualStyleBackColor = false;
            // 
            // button141
            // 
            this.button141.BackColor = System.Drawing.Color.CadetBlue;
            this.button141.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button141.Location = new System.Drawing.Point(909, 255);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(30, 30);
            this.button141.TabIndex = 258;
            this.button141.Text = " ";
            this.button141.UseVisualStyleBackColor = false;
            // 
            // button142
            // 
            this.button142.BackColor = System.Drawing.Color.CadetBlue;
            this.button142.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button142.Location = new System.Drawing.Point(945, 255);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(30, 30);
            this.button142.TabIndex = 257;
            this.button142.Text = " ";
            this.button142.UseVisualStyleBackColor = false;
            // 
            // button143
            // 
            this.button143.BackColor = System.Drawing.Color.CadetBlue;
            this.button143.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button143.Location = new System.Drawing.Point(981, 255);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(30, 30);
            this.button143.TabIndex = 256;
            this.button143.Text = " ";
            this.button143.UseVisualStyleBackColor = false;
            // 
            // button144
            // 
            this.button144.BackColor = System.Drawing.Color.CadetBlue;
            this.button144.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button144.Location = new System.Drawing.Point(1053, 255);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(30, 30);
            this.button144.TabIndex = 255;
            this.button144.Text = " ";
            this.button144.UseVisualStyleBackColor = false;
            // 
            // button145
            // 
            this.button145.BackColor = System.Drawing.Color.CadetBlue;
            this.button145.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button145.Location = new System.Drawing.Point(1089, 255);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(30, 30);
            this.button145.TabIndex = 254;
            this.button145.Text = " ";
            this.button145.UseVisualStyleBackColor = false;
            // 
            // button146
            // 
            this.button146.BackColor = System.Drawing.Color.CadetBlue;
            this.button146.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button146.Location = new System.Drawing.Point(1017, 255);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(30, 30);
            this.button146.TabIndex = 253;
            this.button146.Text = " ";
            this.button146.UseVisualStyleBackColor = false;
            // 
            // button147
            // 
            this.button147.BackColor = System.Drawing.Color.CadetBlue;
            this.button147.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button147.Location = new System.Drawing.Point(1125, 255);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(30, 30);
            this.button147.TabIndex = 252;
            this.button147.Text = " ";
            this.button147.UseVisualStyleBackColor = false;
            // 
            // button148
            // 
            this.button148.BackColor = System.Drawing.Color.CadetBlue;
            this.button148.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button148.Location = new System.Drawing.Point(1161, 255);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(30, 30);
            this.button148.TabIndex = 251;
            this.button148.Text = " ";
            this.button148.UseVisualStyleBackColor = false;
            // 
            // button149
            // 
            this.button149.BackColor = System.Drawing.Color.CadetBlue;
            this.button149.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button149.Location = new System.Drawing.Point(1197, 255);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(30, 30);
            this.button149.TabIndex = 250;
            this.button149.Text = " ";
            this.button149.UseVisualStyleBackColor = false;
            // 
            // button150
            // 
            this.button150.BackColor = System.Drawing.Color.CadetBlue;
            this.button150.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button150.Location = new System.Drawing.Point(873, 255);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(30, 30);
            this.button150.TabIndex = 249;
            this.button150.Text = " ";
            this.button150.UseVisualStyleBackColor = false;
            // 
            // button151
            // 
            this.button151.BackColor = System.Drawing.Color.CadetBlue;
            this.button151.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button151.Location = new System.Drawing.Point(909, 219);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(30, 30);
            this.button151.TabIndex = 248;
            this.button151.Text = " ";
            this.button151.UseVisualStyleBackColor = false;
            // 
            // button152
            // 
            this.button152.BackColor = System.Drawing.Color.CadetBlue;
            this.button152.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button152.Location = new System.Drawing.Point(945, 219);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(30, 30);
            this.button152.TabIndex = 247;
            this.button152.Text = " ";
            this.button152.UseVisualStyleBackColor = false;
            // 
            // button153
            // 
            this.button153.BackColor = System.Drawing.Color.CadetBlue;
            this.button153.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button153.Location = new System.Drawing.Point(981, 219);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(30, 30);
            this.button153.TabIndex = 246;
            this.button153.Text = " ";
            this.button153.UseVisualStyleBackColor = false;
            // 
            // button154
            // 
            this.button154.BackColor = System.Drawing.Color.CadetBlue;
            this.button154.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button154.Location = new System.Drawing.Point(1053, 219);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(30, 30);
            this.button154.TabIndex = 245;
            this.button154.Text = " ";
            this.button154.UseVisualStyleBackColor = false;
            // 
            // button155
            // 
            this.button155.BackColor = System.Drawing.Color.CadetBlue;
            this.button155.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button155.Location = new System.Drawing.Point(1089, 219);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(30, 30);
            this.button155.TabIndex = 244;
            this.button155.Text = " ";
            this.button155.UseVisualStyleBackColor = false;
            // 
            // button156
            // 
            this.button156.BackColor = System.Drawing.Color.CadetBlue;
            this.button156.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button156.Location = new System.Drawing.Point(1017, 219);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(30, 30);
            this.button156.TabIndex = 243;
            this.button156.Text = " ";
            this.button156.UseVisualStyleBackColor = false;
            // 
            // button157
            // 
            this.button157.BackColor = System.Drawing.Color.CadetBlue;
            this.button157.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button157.Location = new System.Drawing.Point(1125, 219);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(30, 30);
            this.button157.TabIndex = 242;
            this.button157.Text = " ";
            this.button157.UseVisualStyleBackColor = false;
            // 
            // button158
            // 
            this.button158.BackColor = System.Drawing.Color.CadetBlue;
            this.button158.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button158.Location = new System.Drawing.Point(1161, 219);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(30, 30);
            this.button158.TabIndex = 241;
            this.button158.Text = " ";
            this.button158.UseVisualStyleBackColor = false;
            // 
            // button159
            // 
            this.button159.BackColor = System.Drawing.Color.CadetBlue;
            this.button159.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button159.Location = new System.Drawing.Point(1197, 219);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(30, 30);
            this.button159.TabIndex = 240;
            this.button159.Text = " ";
            this.button159.UseVisualStyleBackColor = false;
            // 
            // button160
            // 
            this.button160.BackColor = System.Drawing.Color.CadetBlue;
            this.button160.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button160.Location = new System.Drawing.Point(873, 219);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(30, 30);
            this.button160.TabIndex = 239;
            this.button160.Text = " ";
            this.button160.UseVisualStyleBackColor = false;
            // 
            // button161
            // 
            this.button161.BackColor = System.Drawing.Color.CadetBlue;
            this.button161.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button161.Location = new System.Drawing.Point(909, 183);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(30, 30);
            this.button161.TabIndex = 238;
            this.button161.Text = " ";
            this.button161.UseVisualStyleBackColor = false;
            // 
            // button162
            // 
            this.button162.BackColor = System.Drawing.Color.CadetBlue;
            this.button162.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button162.Location = new System.Drawing.Point(945, 183);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(30, 30);
            this.button162.TabIndex = 237;
            this.button162.Text = " ";
            this.button162.UseVisualStyleBackColor = false;
            // 
            // button163
            // 
            this.button163.BackColor = System.Drawing.Color.CadetBlue;
            this.button163.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button163.Location = new System.Drawing.Point(981, 183);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(30, 30);
            this.button163.TabIndex = 236;
            this.button163.Text = " ";
            this.button163.UseVisualStyleBackColor = false;
            // 
            // button164
            // 
            this.button164.BackColor = System.Drawing.Color.CadetBlue;
            this.button164.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button164.Location = new System.Drawing.Point(1053, 183);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(30, 30);
            this.button164.TabIndex = 235;
            this.button164.Text = " ";
            this.button164.UseVisualStyleBackColor = false;
            // 
            // button165
            // 
            this.button165.BackColor = System.Drawing.Color.CadetBlue;
            this.button165.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button165.Location = new System.Drawing.Point(1089, 183);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(30, 30);
            this.button165.TabIndex = 234;
            this.button165.Text = " ";
            this.button165.UseVisualStyleBackColor = false;
            // 
            // button166
            // 
            this.button166.BackColor = System.Drawing.Color.CadetBlue;
            this.button166.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button166.Location = new System.Drawing.Point(1017, 183);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(30, 30);
            this.button166.TabIndex = 233;
            this.button166.Text = " ";
            this.button166.UseVisualStyleBackColor = false;
            // 
            // button167
            // 
            this.button167.BackColor = System.Drawing.Color.CadetBlue;
            this.button167.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button167.Location = new System.Drawing.Point(1125, 183);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(30, 30);
            this.button167.TabIndex = 232;
            this.button167.Text = " ";
            this.button167.UseVisualStyleBackColor = false;
            // 
            // button168
            // 
            this.button168.BackColor = System.Drawing.Color.CadetBlue;
            this.button168.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button168.Location = new System.Drawing.Point(1161, 183);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(30, 30);
            this.button168.TabIndex = 231;
            this.button168.Text = " ";
            this.button168.UseVisualStyleBackColor = false;
            // 
            // button169
            // 
            this.button169.BackColor = System.Drawing.Color.CadetBlue;
            this.button169.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button169.Location = new System.Drawing.Point(1197, 183);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(30, 30);
            this.button169.TabIndex = 230;
            this.button169.Text = " ";
            this.button169.UseVisualStyleBackColor = false;
            // 
            // button170
            // 
            this.button170.BackColor = System.Drawing.Color.CadetBlue;
            this.button170.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button170.Location = new System.Drawing.Point(873, 183);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(30, 30);
            this.button170.TabIndex = 229;
            this.button170.Text = " ";
            this.button170.UseVisualStyleBackColor = false;
            // 
            // button171
            // 
            this.button171.BackColor = System.Drawing.Color.CadetBlue;
            this.button171.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button171.Location = new System.Drawing.Point(909, 147);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(30, 30);
            this.button171.TabIndex = 228;
            this.button171.Text = " ";
            this.button171.UseVisualStyleBackColor = false;
            // 
            // button172
            // 
            this.button172.BackColor = System.Drawing.Color.CadetBlue;
            this.button172.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button172.Location = new System.Drawing.Point(945, 147);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(30, 30);
            this.button172.TabIndex = 227;
            this.button172.Text = " ";
            this.button172.UseVisualStyleBackColor = false;
            // 
            // button173
            // 
            this.button173.BackColor = System.Drawing.Color.CadetBlue;
            this.button173.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button173.Location = new System.Drawing.Point(981, 147);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(30, 30);
            this.button173.TabIndex = 226;
            this.button173.Text = " ";
            this.button173.UseVisualStyleBackColor = false;
            // 
            // button174
            // 
            this.button174.BackColor = System.Drawing.Color.CadetBlue;
            this.button174.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button174.Location = new System.Drawing.Point(1053, 147);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(30, 30);
            this.button174.TabIndex = 225;
            this.button174.Text = " ";
            this.button174.UseVisualStyleBackColor = false;
            // 
            // button175
            // 
            this.button175.BackColor = System.Drawing.Color.CadetBlue;
            this.button175.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button175.Location = new System.Drawing.Point(1089, 147);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(30, 30);
            this.button175.TabIndex = 224;
            this.button175.Text = " ";
            this.button175.UseVisualStyleBackColor = false;
            // 
            // button176
            // 
            this.button176.BackColor = System.Drawing.Color.CadetBlue;
            this.button176.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button176.Location = new System.Drawing.Point(1017, 147);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(30, 30);
            this.button176.TabIndex = 223;
            this.button176.Text = " ";
            this.button176.UseVisualStyleBackColor = false;
            // 
            // button177
            // 
            this.button177.BackColor = System.Drawing.Color.CadetBlue;
            this.button177.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button177.Location = new System.Drawing.Point(1125, 147);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(30, 30);
            this.button177.TabIndex = 222;
            this.button177.Text = " ";
            this.button177.UseVisualStyleBackColor = false;
            // 
            // button178
            // 
            this.button178.BackColor = System.Drawing.Color.CadetBlue;
            this.button178.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button178.Location = new System.Drawing.Point(1161, 147);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(30, 30);
            this.button178.TabIndex = 221;
            this.button178.Text = " ";
            this.button178.UseVisualStyleBackColor = false;
            // 
            // button179
            // 
            this.button179.BackColor = System.Drawing.Color.CadetBlue;
            this.button179.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button179.Location = new System.Drawing.Point(1197, 147);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(30, 30);
            this.button179.TabIndex = 220;
            this.button179.Text = " ";
            this.button179.UseVisualStyleBackColor = false;
            // 
            // button180
            // 
            this.button180.BackColor = System.Drawing.Color.CadetBlue;
            this.button180.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button180.Location = new System.Drawing.Point(873, 147);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(30, 30);
            this.button180.TabIndex = 219;
            this.button180.Text = " ";
            this.button180.UseVisualStyleBackColor = false;
            // 
            // button181
            // 
            this.button181.BackColor = System.Drawing.Color.CadetBlue;
            this.button181.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button181.Location = new System.Drawing.Point(909, 111);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(30, 30);
            this.button181.TabIndex = 218;
            this.button181.Text = " ";
            this.button181.UseVisualStyleBackColor = false;
            // 
            // button182
            // 
            this.button182.BackColor = System.Drawing.Color.CadetBlue;
            this.button182.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button182.Location = new System.Drawing.Point(945, 111);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(30, 30);
            this.button182.TabIndex = 217;
            this.button182.Text = " ";
            this.button182.UseVisualStyleBackColor = false;
            // 
            // button183
            // 
            this.button183.BackColor = System.Drawing.Color.CadetBlue;
            this.button183.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button183.Location = new System.Drawing.Point(981, 111);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(30, 30);
            this.button183.TabIndex = 216;
            this.button183.Text = " ";
            this.button183.UseVisualStyleBackColor = false;
            // 
            // button184
            // 
            this.button184.BackColor = System.Drawing.Color.CadetBlue;
            this.button184.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button184.Location = new System.Drawing.Point(1053, 111);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(30, 30);
            this.button184.TabIndex = 215;
            this.button184.Text = " ";
            this.button184.UseVisualStyleBackColor = false;
            // 
            // button185
            // 
            this.button185.BackColor = System.Drawing.Color.CadetBlue;
            this.button185.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button185.Location = new System.Drawing.Point(1089, 111);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(30, 30);
            this.button185.TabIndex = 214;
            this.button185.Text = " ";
            this.button185.UseVisualStyleBackColor = false;
            // 
            // button186
            // 
            this.button186.BackColor = System.Drawing.Color.CadetBlue;
            this.button186.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button186.Location = new System.Drawing.Point(1017, 111);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(30, 30);
            this.button186.TabIndex = 213;
            this.button186.Text = " ";
            this.button186.UseVisualStyleBackColor = false;
            // 
            // button187
            // 
            this.button187.BackColor = System.Drawing.Color.CadetBlue;
            this.button187.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button187.Location = new System.Drawing.Point(1125, 111);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(30, 30);
            this.button187.TabIndex = 212;
            this.button187.Text = " ";
            this.button187.UseVisualStyleBackColor = false;
            // 
            // button188
            // 
            this.button188.BackColor = System.Drawing.Color.CadetBlue;
            this.button188.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button188.Location = new System.Drawing.Point(1161, 111);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(30, 30);
            this.button188.TabIndex = 211;
            this.button188.Text = " ";
            this.button188.UseVisualStyleBackColor = false;
            // 
            // button189
            // 
            this.button189.BackColor = System.Drawing.Color.CadetBlue;
            this.button189.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button189.Location = new System.Drawing.Point(1197, 111);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(30, 30);
            this.button189.TabIndex = 210;
            this.button189.Text = " ";
            this.button189.UseVisualStyleBackColor = false;
            // 
            // button190
            // 
            this.button190.BackColor = System.Drawing.Color.CadetBlue;
            this.button190.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button190.Location = new System.Drawing.Point(873, 111);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(30, 30);
            this.button190.TabIndex = 209;
            this.button190.Text = " ";
            this.button190.UseVisualStyleBackColor = false;
            // 
            // button191
            // 
            this.button191.BackColor = System.Drawing.Color.CadetBlue;
            this.button191.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button191.Location = new System.Drawing.Point(909, 75);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(30, 30);
            this.button191.TabIndex = 208;
            this.button191.Text = " ";
            this.button191.UseVisualStyleBackColor = false;
            // 
            // button192
            // 
            this.button192.BackColor = System.Drawing.Color.CadetBlue;
            this.button192.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button192.Location = new System.Drawing.Point(945, 75);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(30, 30);
            this.button192.TabIndex = 207;
            this.button192.Text = " ";
            this.button192.UseVisualStyleBackColor = false;
            // 
            // button193
            // 
            this.button193.BackColor = System.Drawing.Color.CadetBlue;
            this.button193.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button193.Location = new System.Drawing.Point(981, 75);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(30, 30);
            this.button193.TabIndex = 206;
            this.button193.Text = " ";
            this.button193.UseVisualStyleBackColor = false;
            // 
            // button194
            // 
            this.button194.BackColor = System.Drawing.Color.CadetBlue;
            this.button194.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button194.Location = new System.Drawing.Point(1053, 75);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(30, 30);
            this.button194.TabIndex = 205;
            this.button194.Text = " ";
            this.button194.UseVisualStyleBackColor = false;
            // 
            // button195
            // 
            this.button195.BackColor = System.Drawing.Color.CadetBlue;
            this.button195.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button195.Location = new System.Drawing.Point(1089, 75);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(30, 30);
            this.button195.TabIndex = 204;
            this.button195.Text = " ";
            this.button195.UseVisualStyleBackColor = false;
            // 
            // button196
            // 
            this.button196.BackColor = System.Drawing.Color.CadetBlue;
            this.button196.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button196.Location = new System.Drawing.Point(1017, 75);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(30, 30);
            this.button196.TabIndex = 203;
            this.button196.Text = " ";
            this.button196.UseVisualStyleBackColor = false;
            // 
            // button197
            // 
            this.button197.BackColor = System.Drawing.Color.CadetBlue;
            this.button197.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button197.Location = new System.Drawing.Point(1125, 75);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(30, 30);
            this.button197.TabIndex = 202;
            this.button197.Text = " ";
            this.button197.UseVisualStyleBackColor = false;
            // 
            // button198
            // 
            this.button198.BackColor = System.Drawing.Color.CadetBlue;
            this.button198.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button198.Location = new System.Drawing.Point(1161, 75);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(30, 30);
            this.button198.TabIndex = 201;
            this.button198.Text = " ";
            this.button198.UseVisualStyleBackColor = false;
            // 
            // button199
            // 
            this.button199.BackColor = System.Drawing.Color.CadetBlue;
            this.button199.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button199.Location = new System.Drawing.Point(1197, 75);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(30, 30);
            this.button199.TabIndex = 200;
            this.button199.Text = " ";
            this.button199.UseVisualStyleBackColor = false;
            // 
            // button200
            // 
            this.button200.BackColor = System.Drawing.Color.CadetBlue;
            this.button200.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button200.Location = new System.Drawing.Point(873, 75);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(30, 30);
            this.button200.TabIndex = 199;
            this.button200.Text = " ";
            this.button200.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(873, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 30);
            this.label3.TabIndex = 198;
            this.label3.Text = "A";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(909, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 30);
            this.label4.TabIndex = 197;
            this.label4.Text = "B";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(945, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 30);
            this.label5.TabIndex = 196;
            this.label5.Text = "C";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(981, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 30);
            this.label6.TabIndex = 195;
            this.label6.Text = "D";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1017, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 30);
            this.label7.TabIndex = 194;
            this.label7.Text = "E";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1053, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 30);
            this.label8.TabIndex = 193;
            this.label8.Text = "F";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(1089, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 30);
            this.label9.TabIndex = 192;
            this.label9.Text = "G";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1161, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 30);
            this.label10.TabIndex = 191;
            this.label10.Text = "I";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1125, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 30);
            this.label11.TabIndex = 190;
            this.label11.Text = "H";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(1197, 45);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(30, 30);
            this.label34.TabIndex = 187;
            this.label34.Text = "J";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1233, 399);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 30);
            this.label2.TabIndex = 310;
            this.label2.Text = "10";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(1233, 75);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(30, 30);
            this.label32.TabIndex = 309;
            this.label32.Text = "1";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(1233, 111);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(30, 30);
            this.label33.TabIndex = 308;
            this.label33.Text = "2";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(1233, 147);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(30, 30);
            this.label35.TabIndex = 307;
            this.label35.Text = "3";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(1233, 183);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(30, 30);
            this.label36.TabIndex = 306;
            this.label36.Text = "4";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(1233, 218);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(30, 30);
            this.label37.TabIndex = 305;
            this.label37.Text = "5";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(1233, 255);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(30, 30);
            this.label38.TabIndex = 304;
            this.label38.Text = "6";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(1233, 291);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(30, 30);
            this.label39.TabIndex = 303;
            this.label39.Text = "7";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(1233, 327);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(30, 30);
            this.label40.TabIndex = 302;
            this.label40.Text = "8";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(1233, 363);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(30, 30);
            this.label41.TabIndex = 301;
            this.label41.Text = "9";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // self
            // 
            this.self.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.self.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.self.Location = new System.Drawing.Point(121, 9);
            this.self.Name = "self";
            this.self.Size = new System.Drawing.Size(210, 30);
            this.self.TabIndex = 311;
            this.self.Text = "Self";
            this.self.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(945, 9);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(210, 30);
            this.label43.TabIndex = 312;
            this.label43.Text = "Opponent";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Battleship",
            "Cruiser",
            "Submarine",
            "Destroyer"});
            this.comboBox1.Location = new System.Drawing.Point(121, 459);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(174, 21);
            this.comboBox1.TabIndex = 313;
            // 
            // button201
            // 
            this.button201.BackColor = System.Drawing.Color.CadetBlue;
            this.button201.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button201.Location = new System.Drawing.Point(135, 541);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(30, 30);
            this.button201.TabIndex = 319;
            this.button201.Text = " ";
            this.button201.UseVisualStyleBackColor = false;
            // 
            // button202
            // 
            this.button202.BackColor = System.Drawing.Color.CadetBlue;
            this.button202.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button202.Location = new System.Drawing.Point(171, 541);
            this.button202.Name = "button202";
            this.button202.Size = new System.Drawing.Size(30, 30);
            this.button202.TabIndex = 318;
            this.button202.Text = " ";
            this.button202.UseVisualStyleBackColor = false;
            // 
            // button203
            // 
            this.button203.BackColor = System.Drawing.Color.CadetBlue;
            this.button203.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button203.Location = new System.Drawing.Point(99, 541);
            this.button203.Name = "button203";
            this.button203.Size = new System.Drawing.Size(30, 30);
            this.button203.TabIndex = 317;
            this.button203.Text = " ";
            this.button203.UseVisualStyleBackColor = false;
            // 
            // button204
            // 
            this.button204.BackColor = System.Drawing.Color.CadetBlue;
            this.button204.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button204.Location = new System.Drawing.Point(207, 541);
            this.button204.Name = "button204";
            this.button204.Size = new System.Drawing.Size(30, 30);
            this.button204.TabIndex = 316;
            this.button204.Text = " ";
            this.button204.UseVisualStyleBackColor = false;
            // 
            // button205
            // 
            this.button205.BackColor = System.Drawing.Color.CadetBlue;
            this.button205.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button205.Location = new System.Drawing.Point(243, 541);
            this.button205.Name = "button205";
            this.button205.Size = new System.Drawing.Size(30, 30);
            this.button205.TabIndex = 315;
            this.button205.Text = " ";
            this.button205.UseVisualStyleBackColor = false;
            // 
            // button206
            // 
            this.button206.BackColor = System.Drawing.Color.CadetBlue;
            this.button206.Cursor = System.Windows.Forms.Cursors.Cross;
            this.button206.Location = new System.Drawing.Point(279, 541);
            this.button206.Name = "button206";
            this.button206.Size = new System.Drawing.Size(30, 30);
            this.button206.TabIndex = 314;
            this.button206.Text = " ";
            this.button206.UseVisualStyleBackColor = false;
            // 
            // button208
            // 
            this.button208.BackColor = System.Drawing.Color.PowderBlue;
            this.button208.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button208.Location = new System.Drawing.Point(99, 598);
            this.button208.Name = "button208";
            this.button208.Size = new System.Drawing.Size(75, 23);
            this.button208.TabIndex = 321;
            this.button208.Text = "Horizontal";
            this.button208.UseVisualStyleBackColor = false;
            // 
            // button209
            // 
            this.button209.BackColor = System.Drawing.Color.PowderBlue;
            this.button209.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button209.Location = new System.Drawing.Point(234, 598);
            this.button209.Name = "button209";
            this.button209.Size = new System.Drawing.Size(75, 23);
            this.button209.TabIndex = 322;
            this.button209.Text = "Vertical";
            this.button209.UseVisualStyleBackColor = false;
            // 
            // button207
            // 
            this.button207.BackColor = System.Drawing.Color.PowderBlue;
            this.button207.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button207.Location = new System.Drawing.Point(577, 203);
            this.button207.Name = "button207";
            this.button207.Size = new System.Drawing.Size(136, 58);
            this.button207.TabIndex = 323;
            this.button207.Text = "START";
            this.button207.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.CadetBlue;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(545, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 30);
            this.label1.TabIndex = 324;
            this.label1.Text = "Opponent\'s Turn";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(1273, 658);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button207);
            this.Controls.Add(this.button209);
            this.Controls.Add(this.button208);
            this.Controls.Add(this.button201);
            this.Controls.Add(this.button202);
            this.Controls.Add(this.button203);
            this.Controls.Add(this.button204);
            this.Controls.Add(this.button205);
            this.Controls.Add(this.button206);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.self);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.button102);
            this.Controls.Add(this.button103);
            this.Controls.Add(this.button104);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button106);
            this.Controls.Add(this.button107);
            this.Controls.Add(this.button108);
            this.Controls.Add(this.button109);
            this.Controls.Add(this.button110);
            this.Controls.Add(this.button111);
            this.Controls.Add(this.button112);
            this.Controls.Add(this.button113);
            this.Controls.Add(this.button114);
            this.Controls.Add(this.button115);
            this.Controls.Add(this.button116);
            this.Controls.Add(this.button117);
            this.Controls.Add(this.button118);
            this.Controls.Add(this.button119);
            this.Controls.Add(this.button120);
            this.Controls.Add(this.button121);
            this.Controls.Add(this.button122);
            this.Controls.Add(this.button123);
            this.Controls.Add(this.button124);
            this.Controls.Add(this.button125);
            this.Controls.Add(this.button126);
            this.Controls.Add(this.button127);
            this.Controls.Add(this.button128);
            this.Controls.Add(this.button129);
            this.Controls.Add(this.button130);
            this.Controls.Add(this.button131);
            this.Controls.Add(this.button132);
            this.Controls.Add(this.button133);
            this.Controls.Add(this.button134);
            this.Controls.Add(this.button135);
            this.Controls.Add(this.button136);
            this.Controls.Add(this.button137);
            this.Controls.Add(this.button138);
            this.Controls.Add(this.button139);
            this.Controls.Add(this.button140);
            this.Controls.Add(this.button141);
            this.Controls.Add(this.button142);
            this.Controls.Add(this.button143);
            this.Controls.Add(this.button144);
            this.Controls.Add(this.button145);
            this.Controls.Add(this.button146);
            this.Controls.Add(this.button147);
            this.Controls.Add(this.button148);
            this.Controls.Add(this.button149);
            this.Controls.Add(this.button150);
            this.Controls.Add(this.button151);
            this.Controls.Add(this.button152);
            this.Controls.Add(this.button153);
            this.Controls.Add(this.button154);
            this.Controls.Add(this.button155);
            this.Controls.Add(this.button156);
            this.Controls.Add(this.button157);
            this.Controls.Add(this.button158);
            this.Controls.Add(this.button159);
            this.Controls.Add(this.button160);
            this.Controls.Add(this.button161);
            this.Controls.Add(this.button162);
            this.Controls.Add(this.button163);
            this.Controls.Add(this.button164);
            this.Controls.Add(this.button165);
            this.Controls.Add(this.button166);
            this.Controls.Add(this.button167);
            this.Controls.Add(this.button168);
            this.Controls.Add(this.button169);
            this.Controls.Add(this.button170);
            this.Controls.Add(this.button171);
            this.Controls.Add(this.button172);
            this.Controls.Add(this.button173);
            this.Controls.Add(this.button174);
            this.Controls.Add(this.button175);
            this.Controls.Add(this.button176);
            this.Controls.Add(this.button177);
            this.Controls.Add(this.button178);
            this.Controls.Add(this.button179);
            this.Controls.Add(this.button180);
            this.Controls.Add(this.button181);
            this.Controls.Add(this.button182);
            this.Controls.Add(this.button183);
            this.Controls.Add(this.button184);
            this.Controls.Add(this.button185);
            this.Controls.Add(this.button186);
            this.Controls.Add(this.button187);
            this.Controls.Add(this.button188);
            this.Controls.Add(this.button189);
            this.Controls.Add(this.button190);
            this.Controls.Add(this.button191);
            this.Controls.Add(this.button192);
            this.Controls.Add(this.button193);
            this.Controls.Add(this.button194);
            this.Controls.Add(this.button195);
            this.Controls.Add(this.button196);
            this.Controls.Add(this.button197);
            this.Controls.Add(this.button198);
            this.Controls.Add(this.button199);
            this.Controls.Add(this.button200);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.button96);
            this.Controls.Add(this.button97);
            this.Controls.Add(this.button98);
            this.Controls.Add(this.button99);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Salvo";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label self;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button201;
        private System.Windows.Forms.Button button202;
        private System.Windows.Forms.Button button203;
        private System.Windows.Forms.Button button204;
        private System.Windows.Forms.Button button205;
        private System.Windows.Forms.Button button206;
        private System.Windows.Forms.Button button208;
        private System.Windows.Forms.Button button209;
        private System.Windows.Forms.Button button207;
        private System.Windows.Forms.Label label1;
    }
}

